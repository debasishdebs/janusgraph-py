#!/usr/bin/env python

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'janusgraph_python',
        version = '0.0.9',
        description = '',
        long_description = 'Python client drivers for JanusGraph',
        author = 'Debasish Kanhar',
        author_email = 'dekanhar@in.ibm.com',
        license = 'Apache License v2.0',
        url = '',
        scripts = ['scripts/janusgraph-python'],
        packages = [
            'janusgraph_python',
            'janusgraph_python.core',
            'janusgraph_python.driver',
            'janusgraph_python.serializer',
            'janusgraph_python.structure',
            'janusgraph_python.utils',
            'janusgraph_python.core.attribute',
            'janusgraph_python.core.datatypes',
            'janusgraph_python.core.attribute.GeoPredicate',
            'janusgraph_python.core.attribute.TextPredicate',
            'janusgraph_python.structure.io'
        ],
        namespace_packages = [],
        py_modules = ['__init__'],
        classifiers = [
            'Development Status :: 3 - Alpha',
            'Programming Language :: Python'
        ],
        entry_points = {},
        data_files = [],
        package_data = {},
        install_requires = ['gremlinpython==3.3.3'],
        dependency_links = [],
        zip_safe = True,
        cmdclass = {'install': install},
        keywords = '',
        python_requires = '',
        obsoletes = [],
    )
